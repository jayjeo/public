
function F = LR_Lmove_equations(x0,theta,beta,u1,p,a,c,z,lambda,eta,L1,L2,birth)

v2=x0(1:1);
w2=x0(2:2);
u2=x0(3:3);

JC=abs(p)-(abs(c)*(1-beta*(1-abs(lambda))))/(beta*(1/(1+theta)))-abs(w2);
WC=eta*p-abs(z)*(1-eta)+(abs(theta))*eta*abs(a)*abs(c)-abs(w2);
UPATH=abs(u1).*L1-a.*theta.*(1./(1+theta)).*abs(u1).*L1+abs(lambda).*(1-abs(u1)).*L1+birth.*L1;
VV=theta*u2-v2;

F(1)=JC;
F(2)=WC;
F(3)=(UPATH/L2-u2);
F(4)=VV;
end
















