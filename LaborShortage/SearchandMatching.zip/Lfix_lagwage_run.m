clear
j=0
for k=1:50
    [result,exitflag] = Lfix_lagwage_values;
    if exitflag==1
        j=j+1;
        v=abs(result(1:33))./10;
        w=abs(result(34:66));
        u=abs(result(67:99))./10;
        xxx(k,:)=[exitflag,v,w,u];
    end
    exitflag
    k
    j
end

xxx(xxx(:, 1)== 0, :)= []
xxx=transpose(xxx);
