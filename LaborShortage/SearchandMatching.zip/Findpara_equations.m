
function F = Findpara_equations(x0,beta,prod,prod_lagged,L,Lfix,vorig,uorig,worig,prod_lagged4)

v=x0(1:33)./100;
w=x0(34:66);
u=x0(67:99)./100;
a=x0(100:100);
c=x0(101:101);
z=x0(102:102);
lambda=x0(103:103);
eta=x0(104:104);

q=(abs(u))./(abs(u)+abs(v));
theta=abs(v)./abs(u);

p=prod;
%thetapredict=0.0154532.*prod-1.372902;
f=0.00277.*prod_lagged4+0.6596579;

LF=abs(v).*L+abs((1-abs(u))).*L-f.*Lfix;
VPATH=abs(v).*L-abs(a).*abs(q).*abs(u).*L+abs(lambda).*abs((1-abs(u))).*L;
EMP=abs((1-abs(u))).*L;
UPATH=abs(u).*L-abs(a).*abs(theta).*abs(q).*abs(u).*L+abs(lambda).*(1-abs(u)).*L;
H=(1-beta+beta.*abs(a).*abs(theta).*abs(q)).*(1-beta+beta.*abs(lambda))-beta.*beta.*abs(lambda).*abs(a).*abs(theta).*abs(q);
M=(1-beta+beta.*abs(a).*abs(q)).*(1-beta+beta.*abs(lambda))-beta.*beta.*abs(lambda).*abs(a).*abs(q);
B=(1-beta+beta.*abs(lambda));
WC=(abs(eta).*abs(p).*H.*M-abs((1-abs(eta))).*(1-beta).*abs(z).*M.*B+abs(eta).*(1-beta).*(abs(a).*abs(c).*B-beta.*abs(a).*abs(q).*abs(p)).*H)./(H.*M+abs((1-abs(eta))).*(1-beta).*beta.*abs(a).*abs(theta).*abs(q).*M-abs(eta).*(1-beta).*beta.*abs(a).*abs(q).*H)-abs(w);
%THETA=thetapredict-theta;

VV=vorig-v;
UU=uorig-u;
WW=worig-w;

F(135)=(v(1)-0.0101743497006158)*1;
%F(136)=(u(1)-0.0770151259006487)*1;

F(1)=LF(1)/1.9;
F(2)=LF(2)/1.9;
F(3)=LF(3)/1.9;
F(4)=LF(4)/1.9;
F(5)=LF(5)/1.9;
F(6)=LF(6)/1.9;
F(7)=LF(7)/1.9;
F(8)=LF(8)/1.9;
F(9)=LF(9)/1.9;
F(10)=LF(10)/1.9;
F(11)=LF(11)/1.9;
F(12)=LF(12)/1.9;
F(13)=LF(13)/1.9;
F(14)=LF(14)/1.9;
F(15)=LF(15)/1.9;
F(16)=LF(16)/1.9;
F(17)=LF(17)/1.9;
F(18)=LF(18)/1.9;
F(19)=LF(19)/1.9;
F(20)=LF(20)/1.9;
F(21)=LF(21)/1.9;
F(22)=LF(22)/1.9;
F(23)=LF(23)/1.9;
F(24)=LF(24)/1.9;
F(25)=LF(25)/1.9;
F(26)=LF(26)/1.9;
F(27)=LF(27)/1.9;
F(28)=LF(28)/1.9;
F(29)=LF(29)/1.9;
F(30)=LF(30)/1.9;
F(31)=LF(31)/1.9;
F(32)=LF(32)/1.9;
F(33)=LF(33)/1.9;

F(34)=VPATH(1)./EMP(2)-v(2);
F(35)=VPATH(2)./EMP(3)-v(3);
F(36)=VPATH(3)./EMP(4)-v(4);
F(37)=VPATH(4)./EMP(5)-v(5);
F(38)=VPATH(5)./EMP(6)-v(6);
F(39)=VPATH(6)./EMP(7)-v(7);
F(40)=VPATH(7)./EMP(8)-v(8);
F(41)=VPATH(8)./EMP(9)-v(9);
F(42)=VPATH(9)./EMP(10)-v(10);
F(43)=VPATH(10)./EMP(11)-v(11);
F(44)=VPATH(11)./EMP(12)-v(12);
F(45)=VPATH(12)./EMP(13)-v(13);
F(46)=VPATH(13)./EMP(14)-v(14);
F(47)=VPATH(14)./EMP(15)-v(15);
F(48)=VPATH(15)./EMP(16)-v(16);
F(49)=VPATH(16)./EMP(17)-v(17);
F(50)=VPATH(17)./EMP(18)-v(18);
F(51)=VPATH(18)./EMP(19)-v(19);
F(52)=VPATH(19)./EMP(20)-v(20);
F(53)=VPATH(20)./EMP(21)-v(21);
F(54)=VPATH(21)./EMP(22)-v(22);
F(55)=VPATH(22)./EMP(23)-v(23);
F(56)=VPATH(23)./EMP(24)-v(24);
F(57)=VPATH(24)./EMP(25)-v(25);
F(58)=VPATH(25)./EMP(26)-v(26);
F(59)=VPATH(26)./EMP(27)-v(27);
F(60)=VPATH(27)./EMP(28)-v(28);
F(61)=VPATH(28)./EMP(29)-v(29);
F(62)=VPATH(29)./EMP(30)-v(30);
F(63)=VPATH(30)./EMP(31)-v(31);
F(64)=VPATH(31)./EMP(32)-v(32);
F(65)=VPATH(32)./EMP(33)-v(33);

F(67)=UPATH(1)./L(2)-u(2);
F(68)=UPATH(2)./L(3)-u(3);
F(69)=UPATH(3)./L(4)-u(4);
F(70)=UPATH(4)./L(5)-u(5);
F(71)=UPATH(5)./L(6)-u(6);
F(72)=UPATH(6)./L(7)-u(7);
F(73)=UPATH(7)./L(8)-u(8);
F(74)=UPATH(8)./L(9)-u(9);
F(75)=UPATH(9)./L(10)-u(10);
F(76)=UPATH(10)./L(11)-u(11);
F(77)=UPATH(11)./L(12)-u(12);
F(78)=UPATH(12)./L(13)-u(13);
F(79)=UPATH(13)./L(14)-u(14);
F(80)=UPATH(14)./L(15)-u(15);
F(81)=UPATH(15)./L(16)-u(16);
F(82)=UPATH(16)./L(17)-u(17);
F(83)=UPATH(17)./L(18)-u(18);
F(84)=UPATH(18)./L(19)-u(19);
F(85)=UPATH(19)./L(20)-u(20);
F(86)=UPATH(20)./L(21)-u(21);
F(87)=UPATH(21)./L(22)-u(22);
F(88)=UPATH(22)./L(23)-u(23);
F(89)=UPATH(23)./L(24)-u(24);
F(90)=UPATH(24)./L(25)-u(25);
F(91)=UPATH(25)./L(26)-u(26);
F(92)=UPATH(26)./L(27)-u(27);
F(93)=UPATH(27)./L(28)-u(28);
F(94)=UPATH(28)./L(29)-u(29);
F(95)=UPATH(29)./L(30)-u(30);
F(96)=UPATH(30)./L(31)-u(31);
F(97)=UPATH(31)./L(32)-u(32);
F(98)=UPATH(32)./L(33)-u(33);

F(100)=WC(1);
F(101)=WC(2);
F(102)=WC(3);
F(103)=WC(4);
F(104)=WC(5);
F(105)=WC(6);
F(106)=WC(7);
F(107)=WC(8);
F(108)=WC(9);
F(109)=WC(10);
F(110)=WC(11);
F(111)=WC(12);
F(112)=WC(13);
F(113)=WC(14);
F(114)=WC(15);
F(115)=WC(16);
F(116)=WC(17);
F(117)=WC(18);
F(118)=WC(19);
F(119)=WC(20);
F(120)=WC(21);
F(121)=WC(22);
F(122)=WC(23);
F(123)=WC(24);
F(124)=WC(25);
F(125)=WC(26);
F(126)=WC(27);
F(127)=WC(28);
F(128)=WC(29);
F(129)=WC(30);
F(130)=WC(31);
F(131)=WC(32);
F(132)=WC(33);

F(133)=VV(1)/0.7;
F(134)=VV(2)/0.7;
F(135)=VV(3)/0.7;
F(136)=VV(4)/0.7;
F(137)=VV(5)/0.7;
F(138)=VV(6)/0.7;
F(139)=VV(7)/0.7;
F(140)=VV(8)/0.7;
F(141)=VV(9)/0.7;
F(142)=VV(10)/0.7;
F(143)=VV(11)/0.7;
F(144)=VV(12)/0.7;
F(145)=VV(13)/0.7;
F(146)=VV(14)/0.7;
F(147)=VV(15)/0.7;
F(148)=VV(16)/0.7;
F(149)=VV(17)/0.7;
F(150)=VV(18)/0.7;
F(151)=VV(19)/0.7;
F(152)=VV(20)/0.7;
F(153)=VV(21)/0.7;
F(154)=VV(22)/0.7;
F(155)=VV(23)/0.7;
F(156)=VV(24)/0.7;
F(157)=VV(25)/0.7;
F(158)=VV(26)/0.7;
F(159)=VV(27)/0.7;
F(160)=VV(28)/0.7;
F(161)=VV(29)/0.7;
F(162)=VV(30)/0.7;
F(163)=VV(31)/0.7;
F(164)=VV(32)/0.7;
F(165)=VV(33)/0.7;

F(166)=UU(1)/1.3;
F(167)=UU(2)/1.3;
F(168)=UU(3)/1.3;
F(169)=UU(4)/1.3;
F(170)=UU(5)/1.3;
F(171)=UU(6)/1.3;
F(172)=UU(7)/1.3;
F(173)=UU(8)/1.3;
F(174)=UU(9)/1.3;
F(175)=UU(10)/1.3;
F(176)=UU(11)/1.3;
F(177)=UU(12)/1.3;
F(178)=UU(13)/1.3;
F(179)=UU(14)/1.3;
F(180)=UU(15)/1.3;
F(181)=UU(16)/1.3;
F(182)=UU(17)/1.3;
F(183)=UU(18)/1.3;
F(184)=UU(19)/1.3;
F(185)=UU(20)/1.3;
F(186)=UU(21)/1.3;
F(187)=UU(22)/1.3;
F(188)=UU(23)/1.3;
F(189)=UU(24)/1.3;
F(190)=UU(25)/1.3;
F(191)=UU(26)/1.3;
F(192)=UU(27)/1.3;
F(193)=UU(28)/1.3;
F(194)=UU(29)/1.3;
F(195)=UU(30)/1.3;
F(196)=UU(31)/1.3;
F(197)=UU(32)/1.3;
F(198)=UU(33)/1.3;

end
















