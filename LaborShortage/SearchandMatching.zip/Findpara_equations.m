
function F = Findpara_equations(x0,beta,prod,f,L,Lfix,vorig,uorig,worig,c,z,eta)

v=x0(1:34)./10;
w=x0(35:68);
u=x0(69:102)./10;
a=x0(103:103);
lambda=x0(104:104);

theta=abs(v)./abs(u);
q=a./(1+theta);
m=(abs(a).*abs(u).*abs(v))./(abs(u)+abs(v));

p=prod;
Firm=f.*Lfix;

LF=abs(v).*L+abs((1-abs(u))).*L-Firm;
VPATH=abs(v).*L-m.*L+abs(lambda).*(1-abs(u)).*L;
UPATH=abs(u).*L-m.*L+abs(lambda).*(1-abs(u)).*L;
H=(1-beta+beta.*abs(theta).*abs(q)).*(1-beta+beta.*abs(lambda))-beta.*beta.*abs(lambda).*abs(theta).*abs(q);
M=(1-beta+beta.*abs(q)).*(1-beta+beta.*abs(lambda))-beta.*beta.*abs(lambda).*abs(q);
B=(1-beta+beta.*abs(lambda));
WC=(abs(eta).*abs(p).*H.*M+abs((1-abs(eta))).*(1-beta).*abs(z).*M.*B+abs(eta).*(1-beta).*abs(p).*(c.*B-beta.*abs(q)).*H)./(H.*M-abs((1-abs(eta))).*(1-beta).*beta.*abs(theta).*abs(q).*M-abs(eta).*(1-beta).*beta.*abs(q).*H)-abs(w);

VV=(vorig-v);
UU=(uorig-u);
%WW=(worig-w);
%WWim=1;

F(132)=(v(1)-.0090196)*1;
%F(136)=(u(1)-0.0770151259006487)*1;

F(1)=LF(1);
F(2)=LF(2);
F(3)=LF(3);
F(4)=LF(4);
F(5)=LF(5);
F(6)=LF(6);
F(7)=LF(7);
F(8)=LF(8);
F(9)=LF(9);
F(10)=LF(10);
F(11)=LF(11);
F(12)=LF(12);
F(13)=LF(13);
F(14)=LF(14);
F(15)=LF(15);
F(16)=LF(16);
F(17)=LF(17);
F(18)=LF(18);
F(19)=LF(19);
F(20)=LF(20);
F(21)=LF(21);
F(22)=LF(22);
F(23)=LF(23);
F(24)=LF(24);
F(25)=LF(25);
F(26)=LF(26);
F(27)=LF(27);
F(28)=LF(28);
F(29)=LF(29);
F(30)=LF(30);
F(31)=LF(31);
F(32)=LF(32);
F(33)=LF(33);
F(34)=LF(34);

F(45)=VPATH(1)-v(2)*L(2);
F(46)=VPATH(2)-v(3)*L(3);
F(47)=VPATH(3)-v(4)*L(4);
F(48)=VPATH(4)-v(5)*L(5);
F(49)=VPATH(5)-v(6)*L(6);
F(50)=VPATH(6)-v(7)*L(7);
F(51)=VPATH(7)-v(8)*L(8);
F(52)=VPATH(8)-v(9)*L(9);
F(53)=VPATH(9)-v(10)*L(10);
F(54)=VPATH(10)-v(11)*L(11);
F(55)=VPATH(11)-v(12)*L(12);
F(56)=VPATH(12)-v(13)*L(13);
F(57)=VPATH(13)-v(14)*L(14);
F(58)=VPATH(14)-v(15)*L(15);
F(59)=VPATH(15)-v(16)*L(16);
F(60)=VPATH(16)-v(17)*L(17);
F(61)=VPATH(17)-v(18)*L(18);
F(62)=VPATH(18)-v(19)*L(19);
F(63)=VPATH(19)-v(20)*L(20);
F(64)=VPATH(20)-v(21)*L(21);
F(65)=VPATH(21)-v(22)*L(22);
F(66)=VPATH(22)-v(23)*L(23);
F(67)=VPATH(23)-v(24)*L(24);
F(68)=VPATH(24)-v(25)*L(25);
F(69)=VPATH(25)-v(26)*L(26);
F(70)=VPATH(26)-v(27)*L(27);
F(71)=VPATH(27)-v(28)*L(28);
F(72)=VPATH(28)-v(29)*L(29);
F(73)=VPATH(29)-v(30)*L(30);
F(74)=VPATH(30)-v(31)*L(31);
F(75)=VPATH(31)-v(32)*L(32);
F(76)=VPATH(32)-v(33)*L(33);
F(77)=VPATH(33)-v(34)*L(34);

F(88)=UPATH(1)-u(2)*L(2);
F(89)=UPATH(2)-u(3)*L(3);
F(90)=UPATH(3)-u(4)*L(4);
F(91)=UPATH(4)-u(5)*L(5);
F(92)=UPATH(5)-u(6)*L(6);
F(93)=UPATH(6)-u(7)*L(7);
F(94)=UPATH(7)-u(8)*L(8);
F(95)=UPATH(8)-u(9)*L(9);
F(96)=UPATH(9)-u(10)*L(10);
F(97)=UPATH(10)-u(11)*L(11);
F(98)=UPATH(11)-u(12)*L(12);
F(99)=UPATH(12)-u(13)*L(13);
F(100)=UPATH(13)-u(14)*L(14);
F(101)=UPATH(14)-u(15)*L(15);
F(102)=UPATH(15)-u(16)*L(16);
F(103)=UPATH(16)-u(17)*L(17);
F(104)=UPATH(17)-u(18)*L(18);
F(105)=UPATH(18)-u(19)*L(19);
F(106)=UPATH(19)-u(20)*L(20);
F(107)=UPATH(20)-u(21)*L(21);
F(108)=UPATH(21)-u(22)*L(22);
F(109)=UPATH(22)-u(23)*L(23);
F(110)=UPATH(23)-u(24)*L(24);
F(111)=UPATH(24)-u(25)*L(25);
F(112)=UPATH(25)-u(26)*L(26);
F(113)=UPATH(26)-u(27)*L(27);
F(114)=UPATH(27)-u(28)*L(28);
F(115)=UPATH(28)-u(29)*L(29);
F(116)=UPATH(29)-u(30)*L(30);
F(117)=UPATH(30)-u(31)*L(31);
F(118)=UPATH(31)-u(32)*L(32);
F(119)=UPATH(32)-u(33)*L(33);
F(120)=UPATH(33)-u(34)*L(34);

F(144)=VV(12);
F(145)=VV(13);
F(146)=VV(14);
F(147)=VV(15);
F(148)=VV(16);
F(149)=VV(17);
F(150)=VV(18);
F(151)=VV(19);
F(152)=VV(20);
F(153)=VV(21);
F(154)=VV(22);
F(155)=VV(23);
F(156)=VV(24);
F(157)=VV(25);
F(158)=VV(26);
F(159)=VV(27);
F(160)=VV(28);
F(161)=VV(29);
F(162)=VV(30);
F(163)=VV(31);
F(164)=VV(32);
F(165)=VV(33);
F(166)=VV(34);

F(189)=UU(12);
F(190)=UU(13);
F(191)=UU(14);
F(192)=UU(15);
F(193)=UU(16);
F(194)=UU(17);
F(195)=UU(18);
F(196)=UU(19);
F(197)=UU(20);
F(198)=UU(21);
F(199)=UU(22);
F(200)=UU(23);
F(201)=UU(24);
F(202)=UU(25);
F(203)=UU(26);
F(204)=UU(27);
F(205)=UU(28);
F(206)=UU(29);
F(207)=UU(30);
F(208)=UU(31);
F(209)=UU(32);
F(210)=UU(33);
F(211)=UU(34);

F(245)=WC(1);
F(245)=WC(2);
F(245)=WC(3);
F(245)=WC(4);
F(245)=WC(5);
F(245)=WC(6);
F(245)=WC(7);
F(245)=WC(8);
F(245)=WC(9);
F(245)=WC(10);
F(245)=WC(11);
F(245)=WC(12);
F(245)=WC(13);
F(245)=WC(14);
F(245)=WC(15);
F(245)=WC(16);
F(245)=WC(17);
F(245)=WC(18);
F(245)=WC(19);
F(245)=WC(20);
F(245)=WC(21);
F(245)=WC(22);
F(245)=WC(23);
F(245)=WC(24);
F(245)=WC(25);
F(245)=WC(26);
F(245)=WC(27);
F(245)=WC(28);
F(245)=WC(29);
F(245)=WC(30);
F(245)=WC(31);
F(245)=WC(32);
F(245)=WC(33);
F(246)=WC(34);

end
















