clear
j=0
for k=1:100
    [result,exitflag] = LRfindpara_values;
    if exitflag==1
        j=j+1
        a=abs(result(1:1));
        c=abs(result(2:2));
        z=abs(result(3:3));
        xxx(k,:)=[exitflag,a,c,z]
    end
    k
    j
end

xxx(xxx(:, 1)== 0, :)= []
xxx=transpose(xxx);
