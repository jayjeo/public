clear
j=0
for k=1:50
    [result,exitflag] = Lmove_lagwage_values;
    if exitflag==1
        j=j+1;
        v=abs(result(1:34))./10;
        w=abs(result(35:68));
        u=abs(result(69:102))./10;
        xxx(k,:)=[exitflag,v,w,u];
    end
    exitflag
    k
    j
end

xxx(xxx(:, 1)== 0, :)= []
xxx=transpose(xxx);
