clear
j=0
for k=1:50
    [result,exitflag] = LR_Lfix_values;
    if exitflag==1
        j=j+1
        v=abs(result(1:1));
        w=abs(result(2:2));
        u=abs(result(3:3));
        xxx(k,:)=[exitflag,v,w,u]
    end
    k
    j
end

xxx(xxx(:, 1)== 0, :)= []
xxx=transpose(xxx);
