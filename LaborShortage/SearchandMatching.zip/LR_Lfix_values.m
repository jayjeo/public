function [result,exitflag] = LR_Lfix_values

theta=0.1339020910674;
beta=0.97;
%v1=0.0103338428709272;
%w1=69.013817790016;
u1=0.0771746190709274;
a=0.0612261652135862;
c=793.843668747888;
z=119.673221474871;
lambda=0.000604649678;  %findlambda.m
eta=0.843939387597103;
p=97.3975;

L1=4028332;
L2=4028332;
birth=0;

optimoptions('fsolve');
options = optimoptions('fsolve');
options.Algorithm = 'Levenberg-Marquardt'
options.MaxFunctionEvaluations = 200000;
options.MaxIterations = 200000;
options.StepTolerance = 1e-5;
options.FunctionTolerance = 1e-5;
options.OptimalityTolerance = 1e-5;

v100 =abs(rand(1,1))/100;
w = p;
u100 = abs(rand(1,1))/100;

x0=[v100,w,u100];

[x0 fval exitflag]=fsolve(@LR_Lfix_equations,x0,options,theta,beta,u1,p,a,c,z,lambda,eta,L1,L2,birth)

result=x0(1,1:3);

end 






