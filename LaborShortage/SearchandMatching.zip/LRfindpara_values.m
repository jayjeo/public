function [result,exitflag] = LRfindpara_values

beta=0.97;
eta=0.843939387597103;
v=0.0103338428709272;
w=69.013817790016;
u=0.0771746190709274;
lambda=0.000604649678;  %findlambda.m
p=97.3975;

optimoptions('fsolve');
options = optimoptions('fsolve');
options.Algorithm = 'Levenberg-Marquardt'
options.MaxFunctionEvaluations = 200000;
options.MaxIterations = 200000;
options.StepTolerance = 1e-9;
options.FunctionTolerance = 1e-9;
options.OptimalityTolerance = 1e-9;

a =abs(rand(1,1))*100;
c =abs(rand(1,1))*1000;
z =abs(rand(1,1))*100;

x0=[a,c,z];

[x0 fval exitflag]=fsolve(@LRfindpara_equations,x0,options,beta,eta,v,w,u,p,lambda)

result=x0(1,1:3);

end 






