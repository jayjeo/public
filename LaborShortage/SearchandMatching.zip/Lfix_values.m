function [result,exitflag] = Lfix_values

Lfix_datain;
beta=0.995097;
a=0.0246400430061289;
c=0.889789438892652;
z=0.342443065085259;
lambda=0.000354773381792437;
eta=0.395353584214886;

optimoptions('fsolve');
options = optimoptions('fsolve');
options.Algorithm = 'Levenberg-Marquardt'
options.MaxFunctionEvaluations = 700000;
options.MaxIterations = 700000;
options.StepTolerance = 1e-8;
options.FunctionTolerance = 1e-8;
options.OptimalityTolerance = 1e-4;

st = 1;
ed=3;
v100 =abs((ed-st).*rand(1,1) + st)+zeros([1 33]);
w = 38+zeros([1 33]);
st = 1;
ed=9;
u100 = abs((ed-st).*rand(1,1) + st)+zeros([1 33]);
x0=[v100,w,u100];

prod=transpose(prod);
prod_lagged4=transpose(prod_lagged4);
L=transpose(L);
Lfix=transpose(Lfix);
vorig=transpose(vorig);
uorig=transpose(uorig);
worig=transpose(worig);

[x0 fval exitflag]=fsolve(@Lfix_equations,x0,options,beta,prod,prod_lagged4,L,Lfix,vorig,uorig,worig,a,c,z,lambda,eta);

result=x0(1,1:99);

end 






