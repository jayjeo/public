syms x

eqn = 1-x == (1-0.0000168007630969252)^36
S = solve(eqn,x,'Real',true)
S

%x=0.000604649678