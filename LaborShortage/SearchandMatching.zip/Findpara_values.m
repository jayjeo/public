function [result,exitflag] = Findpara_values

Findpara_datain;
beta=0.995097;
c=0.986;
z=0.4;
eta=0.5;

optimoptions('fsolve');
options = optimoptions('fsolve');
options.Algorithm = 'Levenberg-Marquardt'
options.MaxFunctionEvaluations = 200000;
options.MaxIterations = 200000;
options.StepTolerance = 1e-8;
options.FunctionTolerance = 1e-8;
options.OptimalityTolerance = 1e-5;

st = 1;
ed=3;
v100 =abs((ed-st).*rand(1,1) + st)+zeros([1 34]);
w = prod(1)+zeros([1 34]);
st = 1;
ed=9;
u100 = abs((ed-st).*rand(1,1) + st)+zeros([1 34]);
a=rand(1,1);
lambda=rand(1,1)/10;
%c=rand(1,1);
%z=rand(1,1);
%eta=rand(1,1);
x0=[v100,w,u100,a,lambda];

prod=transpose(prod);
f=transpose(f);
L=transpose(L);
Lfix=transpose(Lfix);
vorig=transpose(vorig);
uorig=transpose(uorig);
worig=transpose(worig);

[x0 fval exitflag]=fsolve(@Findpara_equations,x0,options,beta,prod,f,L,Lfix,vorig,uorig,worig,c,z,eta);

result=x0(1,1:104);

end 






