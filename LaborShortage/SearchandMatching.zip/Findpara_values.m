function [result,exitflag] = Findpara_values

Findpara_datain;
beta=0.99;

optimoptions('fsolve');
options = optimoptions('fsolve');
options.Algorithm = 'Levenberg-Marquardt'
options.MaxFunctionEvaluations = 100000;
options.MaxIterations = 100000;
options.StepTolerance = 1e-7;
options.FunctionTolerance = 1e-7;
options.OptimalityTolerance = 1e-7;

st = 1;
ed=3;
v1000 =abs((ed-st).*rand(1,1) + st)+zeros([1 33]);
st = 20;
ed=30;
w = 70+rand(1,1)+zeros([1 33]);
st = 1;
ed=9;
u1000 = abs((ed-st).*rand(1,1) + st)+zeros([1 33]);
a=0.001;
c=3;
z=0.1;
lambda=0.002;
eta=0.5;

x0=[v1000,w,u1000,a,c,z,lambda,eta];

prod=transpose(prod);
prod_lagged=transpose(prod_lagged);
L=transpose(L);
Lfix=transpose(Lfix);
vorig=transpose(vorig);
uorig=transpose(uorig);
worig=transpose(worig);
prod_lagged4=transpose(prod_lagged4);

[x0 fval exitflag]=fsolve(@Findpara_equations,x0,options,beta,prod,prod_lagged,L,Lfix,vorig,uorig,worig,prod_lagged4)
exitflag

result=x0(1,1:104);

end 






