
function F = Lmove_lagwage_equations(x0,beta,prod,prod_lagged4,prodfixed,L,Lfix,vorig,uorig,worig,a,c,z,lambda,eta)

v=x0(1:33)./10;
w=x0(34:66);
u=x0(67:99)./10;

theta=abs(v)./abs(u);
q=a./(1+theta);
m=(abs(a).*abs(u).*abs(v))./(abs(u)+abs(v));

p=prod;
f=0.0026048.*prod_lagged4+0.6757813;
Firm=f.*Lfix;

LF=abs(v).*L+abs((1-abs(u))).*L-Firm;
VPATH=abs(v).*L-m.*L+abs(lambda).*(1-abs(u)).*L;
UPATH=abs(u).*L-m.*L+abs(lambda).*(1-abs(u)).*L;
H=(1-beta+beta.*abs(theta).*abs(q)).*(1-beta+beta.*abs(lambda))-beta.*beta.*abs(lambda).*abs(theta).*abs(q);
M=(1-beta+beta.*abs(q)).*(1-beta+beta.*abs(lambda))-beta.*beta.*abs(lambda).*abs(q);
B=(1-beta+beta.*abs(lambda));
WC=(abs(eta).*abs(p).*H.*M+abs((1-abs(eta))).*(1-beta).*abs(z).*M.*B+abs(eta).*(1-beta).*abs(p).*(c.*B-beta.*abs(q)).*H)./(H.*M-abs((1-abs(eta))).*(1-beta).*beta.*abs(theta).*abs(q).*M-abs(eta).*(1-beta).*beta.*abs(q).*H);

%VV=vorig-v;
%UU=uorig-u;
%WW=worig-w;
w0=24.3355664771456;
WCim=1.2;

F(155)=(v(1)-0.00917119155664001)*1;

F(1)=LF(1);
F(2)=LF(2);
F(3)=LF(3);
F(4)=LF(4);
F(5)=LF(5);
F(6)=LF(6);
F(7)=LF(7);
F(8)=LF(8);
F(9)=LF(9);
F(10)=LF(10);
F(11)=LF(11);
F(12)=LF(12);
F(13)=LF(13);
F(14)=LF(14);
F(15)=LF(15);
F(16)=LF(16);
F(17)=LF(17);
F(18)=LF(18);
F(19)=LF(19);
F(20)=LF(20);
F(21)=LF(21);
F(22)=LF(22);
F(23)=LF(23);
F(24)=LF(24);
F(25)=LF(25);
F(26)=LF(26);
F(27)=LF(27);
F(28)=LF(28);
F(29)=LF(29);
F(30)=LF(30);
F(31)=LF(31);
F(32)=LF(32);
F(33)=LF(33);

F(45)=VPATH(1)-v(2)*L(2);
F(46)=VPATH(2)-v(3)*L(3);
F(47)=VPATH(3)-v(4)*L(4);
F(48)=VPATH(4)-v(5)*L(5);
F(49)=VPATH(5)-v(6)*L(6);
F(50)=VPATH(6)-v(7)*L(7);
F(51)=VPATH(7)-v(8)*L(8);
F(52)=VPATH(8)-v(9)*L(9);
F(53)=VPATH(9)-v(10)*L(10);
F(54)=VPATH(10)-v(11)*L(11);
F(55)=VPATH(11)-v(12)*L(12);
F(56)=VPATH(12)-v(13)*L(13);
F(57)=VPATH(13)-v(14)*L(14);
F(58)=VPATH(14)-v(15)*L(15);
F(59)=VPATH(15)-v(16)*L(16);
F(60)=VPATH(16)-v(17)*L(17);
F(61)=VPATH(17)-v(18)*L(18);
F(62)=VPATH(18)-v(19)*L(19);
F(63)=VPATH(19)-v(20)*L(20);
F(64)=VPATH(20)-v(21)*L(21);
F(65)=VPATH(21)-v(22)*L(22);
F(66)=VPATH(22)-v(23)*L(23);
F(67)=VPATH(23)-v(24)*L(24);
F(68)=VPATH(24)-v(25)*L(25);
F(69)=VPATH(25)-v(26)*L(26);
F(70)=VPATH(26)-v(27)*L(27);
F(71)=VPATH(27)-v(28)*L(28);
F(72)=VPATH(28)-v(29)*L(29);
F(73)=VPATH(29)-v(30)*L(30);
F(74)=VPATH(30)-v(31)*L(31);
F(75)=VPATH(31)-v(32)*L(32);
F(76)=VPATH(32)-v(33)*L(33);

F(88)=UPATH(1)-u(2)*L(2);
F(89)=UPATH(2)-u(3)*L(3);
F(90)=UPATH(3)-u(4)*L(4);
F(91)=UPATH(4)-u(5)*L(5);
F(92)=UPATH(5)-u(6)*L(6);
F(93)=UPATH(6)-u(7)*L(7);
F(94)=UPATH(7)-u(8)*L(8);
F(95)=UPATH(8)-u(9)*L(9);
F(96)=UPATH(9)-u(10)*L(10);
F(97)=UPATH(10)-u(11)*L(11);
F(98)=UPATH(11)-u(12)*L(12);
F(99)=UPATH(12)-u(13)*L(13);
F(100)=UPATH(13)-u(14)*L(14);
F(101)=UPATH(14)-u(15)*L(15);
F(102)=UPATH(15)-u(16)*L(16);
F(103)=UPATH(16)-u(17)*L(17);
F(104)=UPATH(17)-u(18)*L(18);
F(105)=UPATH(18)-u(19)*L(19);
F(106)=UPATH(19)-u(20)*L(20);
F(107)=UPATH(20)-u(21)*L(21);
F(108)=UPATH(21)-u(22)*L(22);
F(109)=UPATH(22)-u(23)*L(23);
F(110)=UPATH(23)-u(24)*L(24);
F(111)=UPATH(24)-u(25)*L(25);
F(112)=UPATH(25)-u(26)*L(26);
F(113)=UPATH(26)-u(27)*L(27);
F(114)=UPATH(27)-u(28)*L(28);
F(115)=UPATH(28)-u(29)*L(29);
F(116)=UPATH(29)-u(30)*L(30);
F(117)=UPATH(30)-u(31)*L(31);
F(118)=UPATH(31)-u(32)*L(32);
F(119)=UPATH(32)-u(33)*L(33);

F(120)=(WC(1)*0.05+w0*0.95-w(1))/WCim;
F(121)=(WC(2)*0.05+w(1)*0.95-w(2))/WCim;
F(122)=(WC(3)*0.05+w(2)*0.95-w(3))/WCim;
F(123)=(WC(4)*0.05+w(3)*0.95-w(4))/WCim;
F(124)=(WC(5)*0.05+w(4)*0.95-w(5))/WCim;
F(125)=(WC(6)*0.05+w(5)*0.95-w(6))/WCim;
F(126)=(WC(7)*0.05+w(6)*0.95-w(7))/WCim;
F(127)=(WC(8)*0.05+w(7)*0.95-w(8))/WCim;
F(128)=(WC(9)*0.05+w(8)*0.95-w(9))/WCim;
F(129)=(WC(10)*0.05+w(9)*0.95-w(10))/WCim;
F(130)=(WC(11)*0.05+w(10)*0.95-w(11))/WCim;
F(131)=(WC(12)*0.05+w(11)*0.95-w(12))/WCim;
F(132)=(WC(13)*0.05+w(12)*0.95-w(13))/WCim;
F(133)=(WC(14)*0.05+w(13)*0.95-w(14))/WCim;
F(134)=(WC(15)*0.05+w(14)*0.95-w(15))/WCim;
F(135)=(WC(16)*0.05+w(15)*0.95-w(16))/WCim;
F(136)=(WC(17)*0.05+w(16)*0.95-w(17))/WCim;
F(137)=(WC(18)*0.05+w(17)*0.95-w(18))/WCim;
F(138)=(WC(19)*0.05+w(18)*0.95-w(19))/WCim;
F(139)=(WC(20)*0.05+w(19)*0.95-w(20))/WCim;
F(140)=(WC(21)*0.05+w(20)*0.95-w(21))/WCim;
F(141)=(WC(22)*0.05+w(21)*0.95-w(22))/WCim;
F(142)=(WC(23)*0.05+w(22)*0.95-w(23))/WCim;
F(143)=(WC(24)*0.05+w(23)*0.95-w(24))/WCim;
F(144)=(WC(25)*0.05+w(24)*0.95-w(25))/WCim;
F(145)=(WC(26)*0.05+w(25)*0.95-w(26))/WCim;
F(146)=(WC(27)*0.05+w(26)*0.95-w(27))/WCim;
F(147)=(WC(28)*0.05+w(27)*0.95-w(28))/WCim;
F(148)=(WC(29)*0.05+w(28)*0.95-w(29))/WCim;
F(149)=(WC(30)*0.05+w(29)*0.95-w(30))/WCim;
F(150)=(WC(31)*0.05+w(30)*0.95-w(31))/WCim;
F(151)=(WC(32)*0.05+w(31)*0.95-w(32))/WCim;
F(152)=(WC(33)*0.05+w(32)*0.95-w(33))/WCim;

end
















