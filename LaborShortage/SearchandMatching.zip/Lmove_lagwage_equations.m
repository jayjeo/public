
function F = Lmove_lagwage_equations(x0,beta,prod,f,L,Lfix,vorig,uorig,worig,a,c,z,lambda,eta,alpha)

v=x0(1:34)./10;
w=x0(35:68);
u=x0(69:102)./10;

theta=abs(v)./abs(u);
q=a.*theta.^(alpha-1);
m=a.*abs(v).^alpha.*abs(u).^(1-alpha);

p=prod;
Firm=f.*Lfix;

LF=abs(v).*L+abs((1-abs(u))).*L-Firm;
VPATH=abs(v).*L-m.*L+abs(lambda).*(1-abs(u)).*L;
UPATH=abs(u).*L-m.*L+abs(lambda).*(1-abs(u)).*L;
H=(1-beta+beta.*abs(theta).*abs(q)).*(1-beta+beta.*abs(lambda))-beta.*beta.*abs(lambda).*abs(theta).*abs(q);
M=(1-beta+beta.*abs(q)).*(1-beta+beta.*abs(lambda))-beta.*beta.*abs(lambda).*abs(q);
B=(1-beta+beta.*abs(lambda));
WC=(abs(eta).*abs(p).*H.*M+abs((1-abs(eta))).*(1-beta).*abs(z).*M.*B+abs(eta).*(1-beta).*abs(p).*(c.*B-beta.*abs(q)).*H)./(H.*M-abs((1-abs(eta))).*(1-beta).*beta.*abs(theta).*abs(q).*M-abs(eta).*(1-beta).*beta.*abs(q).*H);

%VV=vorig-v;
%UU=uorig-u;
%WW=worig-w;
sigma=0.99;

F(155)=(v(1)-0.014)*1;
%F(155)=(v(1)-0.00922768829809846)*1;

F(1)=LF(1);
F(2)=LF(2);
F(3)=LF(3);
F(4)=LF(4);
F(5)=LF(5);
F(6)=LF(6);
F(7)=LF(7);
F(8)=LF(8);
F(9)=LF(9);
F(10)=LF(10);
F(11)=LF(11);
F(12)=LF(12);
F(13)=LF(13);
F(14)=LF(14);
F(15)=LF(15);
F(16)=LF(16);
F(17)=LF(17);
F(18)=LF(18);
F(19)=LF(19);
F(20)=LF(20);
F(21)=LF(21);
F(22)=LF(22);
F(23)=LF(23);
F(24)=LF(24);
F(25)=LF(25);
F(26)=LF(26);
F(27)=LF(27);
F(28)=LF(28);
F(29)=LF(29);
F(30)=LF(30);
F(31)=LF(31);
F(32)=LF(32);
F(33)=LF(33);
F(34)=LF(34);

F(45)=VPATH(1)-v(2)*L(2);
F(46)=VPATH(2)-v(3)*L(3);
F(47)=VPATH(3)-v(4)*L(4);
F(48)=VPATH(4)-v(5)*L(5);
F(49)=VPATH(5)-v(6)*L(6);
F(50)=VPATH(6)-v(7)*L(7);
F(51)=VPATH(7)-v(8)*L(8);
F(52)=VPATH(8)-v(9)*L(9);
F(53)=VPATH(9)-v(10)*L(10);
F(54)=VPATH(10)-v(11)*L(11);
F(55)=VPATH(11)-v(12)*L(12);
F(56)=VPATH(12)-v(13)*L(13);
F(57)=VPATH(13)-v(14)*L(14);
F(58)=VPATH(14)-v(15)*L(15);
F(59)=VPATH(15)-v(16)*L(16);
F(60)=VPATH(16)-v(17)*L(17);
F(61)=VPATH(17)-v(18)*L(18);
F(62)=VPATH(18)-v(19)*L(19);
F(63)=VPATH(19)-v(20)*L(20);
F(64)=VPATH(20)-v(21)*L(21);
F(65)=VPATH(21)-v(22)*L(22);
F(66)=VPATH(22)-v(23)*L(23);
F(67)=VPATH(23)-v(24)*L(24);
F(68)=VPATH(24)-v(25)*L(25);
F(69)=VPATH(25)-v(26)*L(26);
F(70)=VPATH(26)-v(27)*L(27);
F(71)=VPATH(27)-v(28)*L(28);
F(72)=VPATH(28)-v(29)*L(29);
F(73)=VPATH(29)-v(30)*L(30);
F(74)=VPATH(30)-v(31)*L(31);
F(75)=VPATH(31)-v(32)*L(32);
F(76)=VPATH(32)-v(33)*L(33);
F(77)=VPATH(33)-v(34)*L(34);

F(88)=UPATH(1)-u(2)*L(2);
F(89)=UPATH(2)-u(3)*L(3);
F(90)=UPATH(3)-u(4)*L(4);
F(91)=UPATH(4)-u(5)*L(5);
F(92)=UPATH(5)-u(6)*L(6);
F(93)=UPATH(6)-u(7)*L(7);
F(94)=UPATH(7)-u(8)*L(8);
F(95)=UPATH(8)-u(9)*L(9);
F(96)=UPATH(9)-u(10)*L(10);
F(97)=UPATH(10)-u(11)*L(11);
F(98)=UPATH(11)-u(12)*L(12);
F(99)=UPATH(12)-u(13)*L(13);
F(100)=UPATH(13)-u(14)*L(14);
F(101)=UPATH(14)-u(15)*L(15);
F(102)=UPATH(15)-u(16)*L(16);
F(103)=UPATH(16)-u(17)*L(17);
F(104)=UPATH(17)-u(18)*L(18);
F(105)=UPATH(18)-u(19)*L(19);
F(106)=UPATH(19)-u(20)*L(20);
F(107)=UPATH(20)-u(21)*L(21);
F(108)=UPATH(21)-u(22)*L(22);
F(109)=UPATH(22)-u(23)*L(23);
F(110)=UPATH(23)-u(24)*L(24);
F(111)=UPATH(24)-u(25)*L(25);
F(112)=UPATH(25)-u(26)*L(26);
F(113)=UPATH(26)-u(27)*L(27);
F(114)=UPATH(27)-u(28)*L(28);
F(115)=UPATH(28)-u(29)*L(29);
F(116)=UPATH(29)-u(30)*L(30);
F(117)=UPATH(30)-u(31)*L(31);
F(118)=UPATH(31)-u(32)*L(32);
F(119)=UPATH(32)-u(33)*L(33);
F(120)=UPATH(33)-u(34)*L(34);

F(120)=0.8106189-w(1);
F(121)=sigma*w(1)+(1-sigma)*WC(2)-w(2);
F(122)=sigma*w(2)+(1-sigma)*WC(3)-w(3);
F(123)=sigma*w(3)+(1-sigma)*WC(4)-w(4);
F(124)=sigma*w(4)+(1-sigma)*WC(5)-w(5);
F(125)=sigma*w(5)+(1-sigma)*WC(6)-w(6);
F(126)=sigma*w(6)+(1-sigma)*WC(7)-w(7);
F(127)=sigma*w(7)+(1-sigma)*WC(8)-w(8);
F(128)=sigma*w(8)+(1-sigma)*WC(9)-w(9);
F(129)=sigma*w(9)+(1-sigma)*WC(10)-w(10);
F(130)=sigma*w(10)+(1-sigma)*WC(11)-w(11);
F(131)=sigma*w(11)+(1-sigma)*WC(12)-w(12);
F(132)=sigma*w(12)+(1-sigma)*WC(13)-w(13);
F(133)=sigma*w(13)+(1-sigma)*WC(14)-w(14);
F(134)=sigma*w(14)+(1-sigma)*WC(15)-w(15);
F(135)=sigma*w(15)+(1-sigma)*WC(16)-w(16);
F(136)=sigma*w(16)+(1-sigma)*WC(17)-w(17);
F(137)=sigma*w(17)+(1-sigma)*WC(18)-w(18);
F(138)=sigma*w(18)+(1-sigma)*WC(19)-w(19);
F(139)=sigma*w(19)+(1-sigma)*WC(20)-w(20);
F(140)=sigma*w(20)+(1-sigma)*WC(21)-w(21);
F(141)=sigma*w(21)+(1-sigma)*WC(22)-w(22);
F(142)=sigma*w(22)+(1-sigma)*WC(23)-w(23);
F(143)=sigma*w(23)+(1-sigma)*WC(24)-w(24);
F(144)=sigma*w(24)+(1-sigma)*WC(25)-w(25);
F(145)=sigma*w(25)+(1-sigma)*WC(26)-w(26);
F(146)=sigma*w(26)+(1-sigma)*WC(27)-w(27);
F(147)=sigma*w(27)+(1-sigma)*WC(28)-w(28);
F(148)=sigma*w(28)+(1-sigma)*WC(29)-w(29);
F(149)=sigma*w(29)+(1-sigma)*WC(30)-w(30);
F(150)=sigma*w(30)+(1-sigma)*WC(31)-w(31);
F(151)=sigma*w(31)+(1-sigma)*WC(32)-w(32);
F(152)=sigma*w(32)+(1-sigma)*WC(33)-w(33);
F(153)=sigma*w(33)+(1-sigma)*WC(34)-w(34);


end
















