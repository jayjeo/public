
function F = LRfindpara_equations(x0,beta,eta,v,w,u,p,lambda)

a=x0(1:1);
c=x0(2:2);
z=x0(3:3);
b=0;

theta=abs(v)/abs(u);
JC=abs(p)-(abs(c)*(1-beta*(1-abs(lambda))))/(beta*(1/(1+theta)))-abs(w);
WC=eta*p-abs(z)*(1-eta)+(abs(theta))*eta*abs(a)*abs(c)-abs(w);
BC=(abs(lambda)+b)./(abs(lambda)+b+abs(a).*(abs(theta)).*(1./(1+abs(theta))))-abs(u);
%UPATH=abs(u).*L-a.*theta.*(1./(1+theta)).*abs(u).*L+abs(lambda).*(1-abs(u)).*L+b.*L;

F(1)=JC;
F(2)=WC*10;
F(3)=BC;

end
















