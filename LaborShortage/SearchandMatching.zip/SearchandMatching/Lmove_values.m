function [result,exitflag] = Lmove_values

Lmove_datain;
beta=0.995097;
c=0.986;
z=0.4;
eta=0.5;
a=0.0361197683884381;
lambda=0.000528433301648602;

optimoptions('fsolve');
options = optimoptions('fsolve');
options.Algorithm = 'Levenberg-Marquardt'
options.MaxFunctionEvaluations = 700000;
options.MaxIterations = 700000;
options.StepTolerance = 1e-8;
options.FunctionTolerance = 1e-8;
options.OptimalityTolerance = 1e-4;

st = 1;
ed=3;
v100 =abs((ed-st).*rand(1,1) + st)+zeros([1 34]);
w = 38+zeros([1 34]);
st = 1;
ed=9;
u100 = abs((ed-st).*rand(1,1) + st)+zeros([1 34]);
x0=[v100,w,u100];

prod=transpose(prod);
f=transpose(f);
L=transpose(L);
Lfix=transpose(Lfix);
vorig=transpose(vorig);
uorig=transpose(uorig);
worig=transpose(worig);

[x0 fval exitflag]=fsolve(@Lmove_equations,x0,options,beta,prod,f,L,Lfix,vorig,uorig,worig,a,c,z,lambda,eta);

result=x0(1,1:102);

end 






