function [result,exitflag] = Lfix_values

Lfix_datain;
beta=0.995097;
c=0.986;
z=0.4;
eta=0.72;

a=0.6653308113;
lambda=0.034;
alpha=0.3187456; %1-0.3187456=0.6812544;

%a= 0.179777960671785;        %hall=0.947;
%lambda=0.0119047385042323;   %hall=0.034;
%alpha= 0.146510665668939;    %shimer=0.765;

optimoptions('fsolve');
options = optimoptions('fsolve');
options.Algorithm = 'Levenberg-Marquardt'
options.MaxFunctionEvaluations = 700000;
options.MaxIterations = 700000;
options.StepTolerance = 1e-6;
options.FunctionTolerance = 1e-6;
options.OptimalityTolerance = 1e-6;

st = 1;
ed=3;
v100 =abs((ed-st).*rand(1,1) + st)+zeros([1 34]);
w = 38+zeros([1 34]);
st = 1;
ed=9;
u100 = abs((ed-st).*rand(1,1) + st)+zeros([1 34]);
x0=[v100,w,u100];

prod=transpose(prod);
f=transpose(f);
L=transpose(L);
Lfix=transpose(Lfix);
vorig=transpose(vorig);
uorig=transpose(uorig);
worig=transpose(worig);

[x0 fval exitflag]=fsolve(@Lfix_equations,x0,options,beta,prod,f,L,Lfix,vorig,uorig,worig,a,c,z,lambda,eta,alpha);

result=x0(1,1:102);

end 






