%%
% Output variable: xxx
% Date: 2019m12~2022m8
% Row 1~33: Vacancy
% Row 34~66: Wage
% Row 67~99: Unemployment

%% To find vacancy,wage,unemployment when L is decreasing by 2%
Lmove_run

%% To find vacancy,wage,unemployment when L is constant
Lfix_run





