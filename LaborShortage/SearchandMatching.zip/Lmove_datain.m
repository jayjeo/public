%% 가져오기 옵션을 설정하고 데이터 가져오기
opts = delimitedTextImportOptions("NumVariables", 8);

% 범위 및 구분 기호 지정
opts.DataLines = [2, Inf];
opts.Delimiter = ",";

% 열 이름과 유형 지정
opts.VariableNames = ["prod","prod_lagged4","L","Lfix","vorig","uorig","worig","prodfixed"];
opts.SelectedVariableNames = ["prod","prod_lagged4","L","Lfix","vorig","uorig","worig","prodfixed"];
opts.VariableTypes = ["double","double","double","double","double","double","double","double"];

% 파일 수준 속성 지정
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule = "read";

% 데이터 가져오기
tbl = readtable("https://raw.githubusercontent.com/jayjeo/public/master/LaborShortage/Lmove.csv", opts);

% 출력 유형으로 변환
prod = tbl.prod;
prod_lagged4 = tbl.prod_lagged4;
L = tbl.L;
Lfix = tbl.Lfix;
vorig = tbl.vorig;
uorig = tbl.uorig;
worig = tbl.worig;
prodfixed = tbl.prodfixed;

% 임시 변수 지우기
clear opts tbl

