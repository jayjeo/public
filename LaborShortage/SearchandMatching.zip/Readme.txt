To run the calibration of a, lambda, and alpha, open calibration.do.

To run the simulation, open main.m, and follow the instruction there.

To run the graph output, open Result report.do.