clear
j=0
for k=1:50
    [result,exitflag] = Findpara_values;
    if exitflag==1||exitflag==3
        j=j+1;
        v=abs(result(1:34))./10;
        w=abs(result(35:68));
        u=abs(result(69:102))./10;
        a=abs(result(103:103));
        lambda=abs(result(104:104));
        %c=abs(result(102:102));
        %z=abs(result(103:103));
        %eta=abs(result(102:102));
        xxx(k,:)=[exitflag,v,w,u,a,lambda];
    end
    exitflag
    k
    j
end

xxx(xxx(:, 1)== 0, :)= []
xxx=transpose(xxx);
