clear
j=0
for k=1:30
    [result,exitflag] = Findpara_values;
    if exitflag==1
        j=j+1
        v=abs(result(1:33))./100;
        w=abs(result(34:66));
        u=abs(result(67:99))./100;
        a=abs(result(100:100));
        c=abs(result(101:101));
        z=abs(result(102:102));
        lambda=abs(result(103:103));
        eta=abs(result(104:104));
        xxx(k,:)=[exitflag,v,w,u,a,c,z,lambda,eta]
    end
    k
    j
end

xxx(xxx(:, 1)== 0, :)= []
xxx=transpose(xxx);
