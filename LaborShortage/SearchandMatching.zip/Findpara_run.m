clear
j=0
for k=1:50
    [result,exitflag] = Findpara_values;
    if exitflag==1||exitflag==3
        j=j+1;
        v=abs(result(1:33))./10;
        w=abs(result(34:66));
        u=abs(result(67:99))./10;
        a=abs(result(100:100));
        lambda=abs(result(101:101));
        c=abs(result(102:102));
        z=abs(result(103:103));
        eta=abs(result(104:104));
        xxx(k,:)=[exitflag,v,w,u,a,lambda,c,z,eta];
    end
    exitflag
    k
    j
end

xxx(xxx(:, 1)== 0, :)= []
xxx=transpose(xxx);
