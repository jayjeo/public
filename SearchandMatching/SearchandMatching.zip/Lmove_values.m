function [result,exitflag] = Lmove_values

Lmove_datain;
beta=0.99;
a=0.000922401588815075;
c=3.00108244445731;
z=0.873280847191347;
lambda=0.0000665202471508203;
eta=0.732951549664879;

optimoptions('fsolve');
options = optimoptions('fsolve');
options.Algorithm = 'Levenberg-Marquardt'
options.MaxFunctionEvaluations = 200000;
options.MaxIterations = 200000;
options.StepTolerance = 1e-9;
options.FunctionTolerance = 1e-8;
options.OptimalityTolerance = 1e-9;

st = 1;
ed=3;
v100 =abs((ed-st).*rand(1,1) + st)+zeros([1 33]);
st = 20;
ed=30;
w = prod(1)+zeros([1 33]);
st = 1;
ed=9;
u100 = abs((ed-st).*rand(1,1) + st)+zeros([1 33]);

x0=[v100,w,u100];

prod=transpose(prod);
prod_lagged=transpose(prod_lagged);
L=transpose(L);
Lfix=transpose(Lfix);
vorig=transpose(vorig);
uorig=transpose(uorig);
worig=transpose(worig);
prod_lagged4=transpose(prod_lagged4);

[x0 fval exitflag]=fsolve(@Lmove_equations,x0,options,beta,prod,prod_lagged,L,Lfix,vorig,uorig,worig,prod_lagged4,a,c,z,lambda,eta)
exitflag

result=x0(1,1:99);

end 






