%%
% Output variable: xxx
% Date: 2019m12~2022m8
% Row 1~33: Vacancy
% Row 34~66: Wage
% Row 67~99: Unemployment
% Row 100: a (matching efficiency)
% Row 101: c (search cost factor)
% Row 102: z (Unemployed benefit)
% Row 103: lambda (job destruction rate)
% Row 104: eta (workers bagaining power)

%% To find parameters (a,c,z,lambda,eta)
Findpara_run

%% To find vacancy when L is decreasing
Lmove_run

%% To find vacancy when L is fixed
Lfix_run


